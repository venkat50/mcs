package utils;

import java.io.IOException;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.tangosol.io.pof.PofReader;
import com.tangosol.io.pof.PofSerializer;
import com.tangosol.io.pof.PofWriter;

import model.Customer;


public class CustomerSerializer implements PofSerializer {

    
    
    public void serialize(PofWriter writer, Object o) throws IOException {

        Customer c = (Customer) o;
        writer.writeInt(ID, c.getCustomerId());
        
        writer.writeString(ADDR1, c.getAddressline1());
        writer.writeString(ADDR2, c.getAddressline2());
        writer.writeString(CITY, c.getCity());
        writer.writeString(EMAIL, c.getEmail());
        writer.writeString(FAX, c.getFax());
        writer.writeString(NAME, c.getName());
        writer.writeString(PHONE, c.getPhone());
        writer.writeString(STATE, c.getState());
        writer.writeString(ZIP, c.getZip());
                
        //Very important to do that- it tells we are finished writing
        writer.writeRemainder(null);

    }

    public Object deserialize(PofReader reader) throws IOException {
        
        int id = reader.readInt(ID);
        Customer c = new Customer(id);
        
                
        c.setAddressline1(reader.readString(ADDR1));
        c.setAddressline2(reader.readString(ADDR2));
        c.setCity(reader.readString(CITY));
        c.setEmail(reader.readString(EMAIL));
        c.setFax(reader.readString(FAX));
        c.setName(reader.readString(NAME));
        c.setPhone(reader.readString(PHONE));
        c.setState(reader.readString(STATE));
        c.setZip(reader.readString(ZIP));
        //Very important to do that- it tells we are finished reading
        reader.readRemainder();
        
        return c;
    }
    
    public static final int ID = 1;
    public static final int ADDR1 = 2;
    public static final int ADDR2 = 3;
    public static final int CITY = 4;
    public static final int EMAIL = 5;
    public static final int FAX = 6;
    public static final int NAME = 7;
    public static final int PHONE = 8;
    public static final int STATE = 9;
    public static final int ZIP = 10;
    
    
    
    

}
